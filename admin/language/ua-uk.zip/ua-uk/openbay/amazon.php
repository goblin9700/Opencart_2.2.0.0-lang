<?php
// Heading
$_['heading_title']         		= 'Amazon EU';
$_['text_openbay']					= 'OpenBay Pro';
$_['text_dashboard']				= 'Панель приладів Amazon EU ';

// Text
$_['text_heading_settings'] 		= 'Налаштування';
$_['text_heading_account'] 			= 'Зміна плану';
$_['text_heading_links'] 			= 'Посилання на елементи';
$_['text_heading_register'] 		= 'Реєстрація';
$_['text_heading_bulk_listing'] 	= 'Сумарний список';
$_['text_heading_stock_updates'] 	= 'Оновлення залишку';
$_['text_heading_saved_listings'] 	= 'Збереження списку';
$_['text_heading_bulk_linking'] 	= 'Сумарні посилання';