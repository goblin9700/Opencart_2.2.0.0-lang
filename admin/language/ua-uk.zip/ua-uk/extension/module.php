<?php
// Heading
$_['heading_title']    = 'Модулі';

// Text
$_['text_success']     = 'Успіх: Модулі змінено!';
$_['text_layout']      = 'Після інсталяції та настроювання модуль можна додати до схеми, <a href="%s" class="alert-link"> тут</a>!';
$_['text_list']        = 'Список модулів';

// Column
$_['column_name']      = 'Назва модуля';
$_['column_action']    = 'Дія';

// Error
$_['error_permission'] = 'Попередження: У Вас немає дозволу на змінення модулів!';