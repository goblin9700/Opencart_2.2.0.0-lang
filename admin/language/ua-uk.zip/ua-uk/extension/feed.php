<?php
// Heading
$_['heading_title']    = 'Канали просування';

// Text
$_['text_success']     = 'Успіх: Канали просування змінено!';
$_['text_list']        = 'Список каналів';

// Column
$_['column_name']      = 'Назва каналу товарів';
$_['column_status']    = 'Стан';
$_['column_action']    = 'Дія';

// Error
$_['error_permission'] = 'Попередження: У Вас немає дозволу на змінення каналів!';