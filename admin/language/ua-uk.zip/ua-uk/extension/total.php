<?php
// Heading
$_['heading_title']     = 'Загально замовлено';

// Text
$_['text_success']      = 'Успіх: Підсумки змінено!';
$_['text_list']         = 'Загальний список замовлень';

// Column
$_['column_name']       = 'Загально замовлено';
$_['column_status']     = 'Стан';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action']     = 'Дія';

// Error
$_['error_permission']  = 'Попередження: У Вас немає дозволу на змінення замовлень!';