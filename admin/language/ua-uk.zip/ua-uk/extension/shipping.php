<?php
// Heading
$_['heading_title']     = 'Доставка';

// Text
$_['text_success']      = 'Успіх: Доставку змінено!';
$_['text_list']         = 'Список доставки';

// Column
$_['column_name']       = 'Спосіб доставки';
$_['column_status']     = 'Стан';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action']     = 'Дія';

// Error
$_['error_permission']  = 'Попередження: Ви не маєте дозволу на змінення доставка!';