<?php
// Heading
$_['heading_title']     = 'Платежі';

// Text
$_['text_success']      = 'Успіх: Платежі змінено!';
$_['text_list']         = 'Список оплати';

// Column
$_['column_name']       = 'Метод оплати';
$_['column_status']     = 'Стан';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action']     = 'Дія';

// Error
$_['error_permission']  = 'Попередження: У Вас немає дозволу на змінення платежів!';