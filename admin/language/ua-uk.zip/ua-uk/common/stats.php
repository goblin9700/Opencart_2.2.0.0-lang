<?php
$_['text_complete_status']   = 'Завершені замовлення'; 
$_['text_processing_status'] = 'Замовлення, що обробляються'; 
$_['text_other_status']      = 'Інші статуси'; 