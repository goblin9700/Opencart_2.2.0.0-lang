<?php
// Heading
$_['heading_title']    = 'Кнопка оформлення замовлення PayPal Express';

// Text
$_['text_module']      = 'Модулі';
$_['text_success']     = 'Успіх: Модуль кнопка оформлення замовлення PayPal Express змінено!';
$_['text_edit']        = 'Змінити модуль кнопка оформлення замовлення PayPal Express';

// Entry
$_['entry_status']     = 'Стан';

// Error
$_['error_permission'] = 'Попередження: Нема дозволу на зміни модуля кнопки оформлення замовлення PayPal Express!';