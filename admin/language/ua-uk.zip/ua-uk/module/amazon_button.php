<?php
// Heading
$_['heading_title']    = 'Кнопка платежів Amazon';

$_['text_module']      = 'Модулі';
$_['text_success']     = 'Успіх: Модуль платежів Amazon змінено!';
$_['text_edit']        = 'Змінити модуль платежів Amazon';

// Entry
$_['entry_status']     = 'Стан';

// Error
$_['error_permission'] = 'Попередження: Нема дозволу на зміни модуля платежів Amazon!';