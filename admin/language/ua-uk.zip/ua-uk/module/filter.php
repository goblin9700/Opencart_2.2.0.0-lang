<?php
// Heading
$_['heading_title']    = 'Фільтр';

// Text
$_['text_module']      = 'Модулі';
$_['text_success']     = 'Успіх: Модуль фільтр змінено!';
$_['text_edit']        = 'Змінити модуль фільтр';

// Entry
$_['entry_status']     = 'Стан';

// Error
$_['error_permission'] = 'Попередження: Немає дозволу на зміну модуля фільтр!';