<?php
// Heading
$_['heading_title']    = 'Магазин';

// Text
$_['text_module']      = 'Модулі';
$_['text_success']     = 'Успіх: Модуль магазин змінено!';
$_['text_edit']        = 'Змінити модуль магазин';

// Entry
$_['entry_admin']      = 'Тільки адміністратори';
$_['entry_status']     = 'Стан';

// Error
$_['error_permission'] = 'Попередження: Немає дозволу на зміну модуля магазин!';