<?php
// Heading
$_['heading_title']    = 'Інформація';

// Text
$_['text_module']      = 'Модулі';
$_['text_success']     = 'Успіх: Модуль інформації змінено!';
$_['text_edit']        = 'Змінити модуль інформації';

// Entry
$_['entry_status']     = 'Стан';

// Error
$_['error_permission'] = 'Попередження: Нема дозволу на зміни модуля інформації!';