<?php
// Heading
$_['heading_title']    = 'Категорія';

// Text
$_['text_module']      = 'Модулі';
$_['text_success']     = 'Успіх: Модуль категорії змінено!';
$_['text_edit']        = 'Змінити модуль категорій';

// Entry
$_['entry_status']     = 'Стан';

// Error
$_['error_permission'] = 'Попередження: Немає дозволу на зміну модуля категорій!';