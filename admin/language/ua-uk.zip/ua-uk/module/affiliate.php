<?php
// Heading
$_['heading_title']    = 'Партнери';

$_['text_module']      = 'Модулі';
$_['text_success']     = 'Успіх: Модуль партнери змінено!';
$_['text_edit']        = 'Змінити  модуль партнери';

// Entry
$_['entry_status']     = 'Стан';

// Error
$_['error_permission'] = 'Попередження: Немає дозволу на зміни  модуля партнери!';