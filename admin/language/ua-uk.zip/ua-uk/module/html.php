<?php
// Heading
$_['heading_title']     = 'HTML контент';

// Text
$_['text_module']       = 'Модулі';
$_['text_success']      = 'Успіх: Модуль HTML контент змінено!';
$_['text_edit']         = 'Змінити модуль HTML контент';

// Entry
$_['entry_heading']     = 'Назва заголовка';
$_['entry_description'] = 'Зміст';
$_['entry_status']      = 'Стан';

// Error
$_['error_permission']  = 'Увага: Ви не маєте дозволу змінювати модуль HTML контенту!';
$_['error_module']      = 'Попередження: Потрібен модуль!';