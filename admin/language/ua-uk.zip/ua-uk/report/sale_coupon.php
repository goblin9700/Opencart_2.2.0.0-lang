<?php
// Heading
$_['heading_title']    = 'Звіт по купонах';

// Text
$_['text_list']        = 'Список купонів';

// Column
$_['column_name']      = 'Назва купону';
$_['column_code']      = 'Код';
$_['column_orders']    = 'Замовлення';
$_['column_total']     = 'Всього';
$_['column_action']    = 'Дія';

// Entry
$_['entry_date_start'] = 'Дата початку';
$_['entry_date_end']   = 'Дата кінця';