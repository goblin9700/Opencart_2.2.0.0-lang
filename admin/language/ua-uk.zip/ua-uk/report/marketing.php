<?php
// Heading
$_['heading_title']    = 'Статистика продаж';

// Text
$_['text_list']         = 'Список продаж';
$_['text_all_status']   = 'Всі статуси';

// Column
$_['column_campaign']  = 'Назва кампанії';
$_['column_code']      = 'Код';
$_['column_clicks']    = 'Натиснення';
$_['column_orders']    = '№ Замовлення';
$_['column_total']     = 'Всього';

// Entry
$_['entry_date_start'] = 'Дата початку';
$_['entry_date_end']   = 'Дата кінця';
$_['entry_status']     = 'Стан замовлення';