<?php
// Heading
$_['heading_title']     = 'Звіт по відвідувачам онлайн';

// Text
$_['text_list']         = 'Список онлайн користувачів';
$_['text_guest']        = 'Гість';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Користувач';
$_['column_url']        = 'Остання відвідувана сторінка';
$_['column_referer']    = 'Реферальне посилання';
$_['column_date_added'] = 'Останнє натискання мишкою';
$_['column_action']     = 'Дія';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = 'Користувач';