<?php
// Heading
$_['heading_title']     = 'Звіт куплених товарів';

// Text
$_['text_list']         = 'Список куплених товарів';
$_['text_all_status']   = 'Всі статуси';

// Column
$_['column_date_start'] = 'Дата початку';
$_['column_date_end']   = 'Дата кінця';
$_['column_name']       = 'Назва товару';
$_['column_model']      = 'Модель';
$_['column_quantity']   = 'Кількість';
$_['column_total']      = 'Всього';

// Entry
$_['entry_date_start']  = 'Дата початку';
$_['entry_date_end']    = 'Дата кінця';
$_['entry_status']      = 'Стан замовлення';