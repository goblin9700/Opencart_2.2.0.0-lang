<?php
// Heading
$_['heading_title']         = 'Кредитний звіт користувача';

// Column
$_['text_list']             = 'Список кредитів користувача';
$_['column_customer']       = 'Ім\'я клієнта';
$_['column_email']          = 'Електронна пошта';
$_['column_customer_group'] = 'Групи клієнтів';
$_['column_status']         = 'Стан';
$_['column_total']          = 'Загалом';
$_['column_action']         = 'Дія';

// Entry
$_['entry_date_start']      = 'Дата початку';
$_['entry_date_end']        = 'Дата кінця';