<?php
// Heading
$_['heading_title']         = 'Звіт про бонусні бали користувача';

// Text
$_['text_list']             = 'Список бонусних балів користувача';

// Column
$_['column_customer']       = 'Ім\'я користувача';
$_['column_email']          = 'Електронна пошта';
$_['column_customer_group'] = 'Група користувача';
$_['column_status']         = 'Стан';
$_['column_points']         = 'Нарахування балів';
$_['column_orders']         = '№ Замовлення';
$_['column_total']          = 'Всього';
$_['column_action']         = 'Дія';

// Entry
$_['entry_date_start']      = 'Дата початку';
$_['entry_date_end']        = 'Дата кінця';