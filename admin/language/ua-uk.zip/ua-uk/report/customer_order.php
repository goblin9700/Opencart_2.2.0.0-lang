<?php
// Heading
$_['heading_title']         = 'Звіт замовлень користувачів';

// Text
$_['text_list']             = 'Список замовлень користувачів';
$_['text_all_status']       = 'Всі статуси';

// Column
$_['column_customer']       = 'Ім\'я користувача';
$_['column_email']          = 'Електронна пошта';
$_['column_customer_group'] = 'Групи клієнтів';
$_['column_status']         = 'Стан';
$_['column_orders']         = '№ Замовлення';
$_['column_products']       = '№ Товара';
$_['column_total']          = 'Загалом';
$_['column_action']         = 'Дія';

// Entry
$_['entry_date_start']      = 'Дата початку';
$_['entry_date_end']        = 'Дата кінця';
$_['entry_status']          = 'Стан замовлення';