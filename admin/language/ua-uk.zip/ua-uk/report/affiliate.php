<?php
// Heading
$_['heading_title']     = 'Звіт партнерської комісії';

// Text
$_['text_list']         = 'Список партнерської комісії';

// Column
$_['column_affiliate']  = 'Партнерське ім\'я';
$_['column_email']      = 'Електронна пошта';
$_['column_status']     = 'Стан';
$_['column_commission'] = 'Комісія';
$_['column_orders']     = '№ Замовлення';
$_['column_total']      = 'Загалом';
$_['column_action']     = 'Дія';

// Entry
$_['entry_date_start']  = 'Дата початку';
$_['entry_date_end']    = 'Дата кінця';