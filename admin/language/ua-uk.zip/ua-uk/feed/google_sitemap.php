<?php
// Heading
$_['heading_title']    = 'Google карта сайту';

// Text
$_['text_feed']        = 'Канали просування';
$_['text_success']     = 'Успіх: Google мапа сайту змінено!';
$_['text_list']        = 'Список схем';

// Entry
$_['entry_status']     = 'Стан';
$_['entry_data_feed']  = 'Посилання на канал просування';

// Error
$_['error_permission'] = 'Попередження: У вас немає прав на внесення змін до  каналів просування Google мапа сайту!';