<?php
// Heading
$_['heading_title']	  = 'OpenBay Pro';

// Text
$_['text_module']    = 'Модулі';
$_['text_installed'] = 'Наразі встановлюється модуль OpenBay Pro. Він доступний в меню розширення-> OpenBay Pro';