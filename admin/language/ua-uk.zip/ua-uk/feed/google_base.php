<?php
// Heading
$_['heading_title']    = 'Google Base';

// Text
$_['text_feed']        = 'Канали просування';
$_['text_success']     = 'Успіх: Змінено канал Google Base!';
$_['text_list']        = 'Список схем';

// Entry
$_['entry_status']     = 'Стан';
$_['entry_data_feed']  = 'Посилання на канал просування';

// Error
$_['error_permission'] = 'Попередження: У вас немає прав на внесення змін до  каналів просування Google Base!';