<?php
// Heading
$_['heading_title']					= 'Повернення транзакції';

// Text
$_['text_pp_express']				= 'Оформити замовлення PayPal Експрес';
$_['text_current_refunds']			= 'Повернення грошей не було вже зроблено для цієї операції. Макс повернення є';

// Entry
$_['entry_transaction_id']			= 'Ідентифікатор транзакції';
$_['entry_full_refund']				= 'Повне повернення';
$_['entry_amount']					= 'Кількість';
$_['entry_message']					= 'Повідомлення';

// Button
$_['button_refund']					= 'Питання відшкодування';

// Error
$_['error_partial_amt']				= 'Ви повинні ввести часткове відшкодування суми';
$_['error_data']					= 'Даних зниклих без вести з запитом';