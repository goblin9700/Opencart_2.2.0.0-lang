<?php
// Heading
$_['heading_title']		 = 'Free Checkout';

// Text
$_['text_payment']		 = 'Платежі';
$_['text_success']		 = 'Success: You have modified Free Checkout payment module!';
$_['text_edit']          = 'Edit Free Checkout';

// Entry
$_['entry_order_status'] = 'Стан замовлення';
$_['entry_status']		 = 'Стан';
$_['entry_sort_order']	 = 'Порядок сортування';

// Error
$_['error_permission']	  = 'Warning: You do not have permission to modify payment Free Checkout!';