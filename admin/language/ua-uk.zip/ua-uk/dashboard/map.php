<?php
// Heading
$_['heading_title'] = 'Мапа світу';

$_['text_order']    = 'Замовлення';
$_['text_sale']     = 'Продажі';