<?php
// Heading
$_['heading_title'] = 'Загальна кількість клієнтів';

// Text
$_['text_view'] = 'Розглядайте більше...';