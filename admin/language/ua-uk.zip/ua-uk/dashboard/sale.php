<?php
// Heading
$_['heading_title'] = 'Загальний обсяг продажу';

// Text
$_['text_view']     = 'Розглядайте більше...';