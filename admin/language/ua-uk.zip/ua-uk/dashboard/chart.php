<?php
// Heading
$_['heading_title'] = 'Аніліз продажів';

// Text
$_['text_order']    = 'Замовлення';
$_['text_customer'] = 'Клієнти';
$_['text_day']      = 'Сьогодні';
$_['text_week']     = 'Тиждень';
$_['text_month']    = 'Місяць';
$_['text_year']     = 'Рік';