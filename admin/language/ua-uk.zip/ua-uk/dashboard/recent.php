<?php
// Heading
$_['heading_title']     = 'Останні замовлення';

// Column
$_['column_order_id']   = 'КОД замовлення';
$_['column_customer']   = 'Клієнт';
$_['column_status']     = 'Статус';
$_['column_total']      = 'Всього';
$_['column_date_added'] = 'Дата додавання';
$_['column_action']     = 'Дія';