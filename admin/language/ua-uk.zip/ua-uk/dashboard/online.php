<?php
// Heading
$_['heading_title'] = 'Люди онлайн';

// Text
$_['text_view']     = 'Розглядайте більше...';