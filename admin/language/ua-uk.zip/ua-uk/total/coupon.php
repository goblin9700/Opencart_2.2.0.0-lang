<?php
// Heading
$_['heading_title']    = 'Купон';

// Text
$_['text_total']       = 'Всього замовлено';
$_['text_success']     = 'Успіх: Купон всього змінено!';
$_['text_edit']        = 'Змінити купон';

// Entry
$_['entry_status']     = 'Стан';
$_['entry_sort_order'] = 'Порядок сортування';

// Error
$_['error_permission'] = 'Попередження: Не має дозволу змінювати купон всього!';