<?php
// Heading
$_['heading_title']    = 'Доставка';

// Text
$_['text_total']       = 'Загально замовлено';
$_['text_success']     = 'Успіх: Загальну доставку змінено!';
$_['text_edit']        = 'Змінити загальну доставку';

// Entry
$_['entry_estimator']  = 'Оцінювач доставки';
$_['entry_status']     = 'Стан';
$_['entry_sort_order'] = 'Порядок сортування';

// Error
$_['error_permission'] = 'Попередження: Не має дозволу змінювати загальну доставку!';