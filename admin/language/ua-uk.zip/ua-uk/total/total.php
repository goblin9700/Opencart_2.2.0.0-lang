<?php
// Heading
$_['heading_title']    = 'Загалом';

// Text
$_['text_total']       = 'Загально замовлено';
$_['text_success']     = 'Успіх: Змінено загальні підсумки!';
$_['text_edit']        = 'Змінити загальний підсумок';

// Entry
$_['entry_status']     = 'Стан';
$_['entry_sort_order'] = 'Порядок сортування';

// Error
$_['error_permission'] = 'Попередження: Не має дозволу змінювати загальні підсумки!';