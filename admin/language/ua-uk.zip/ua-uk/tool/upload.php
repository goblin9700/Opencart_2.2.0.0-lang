<?php
// Heading
$_['heading_title']     = 'Вивантаження';

// Text
$_['text_success']      = 'Успіх: Вивантаження змінено!';
$_['text_list']         = 'Вивантажити список';

// Column
$_['column_name']       = 'Вивантажити ім\'я';
$_['column_filename']   = 'Ім\'я файлу';
$_['column_date_added'] = 'Дата додавання';
$_['column_action']     = 'Дія';

// Entry
$_['entry_name']        = 'Вивантажити ім\'я';
$_['entry_filename']    = 'Ім\'я файлу';
$_['entry_date_added'] 	= 'Дата додавання';

// Error
$_['error_permission']  = 'Попередження: У Вас немає дозволу на змінення вивантажень!';